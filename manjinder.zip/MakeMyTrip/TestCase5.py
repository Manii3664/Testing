from selenium import webdriver
from selenium.webdriver.support.select import Select

driver = webdriver.Chrome(executable_path="c:\\chromedriver.exe")
driver.get("https://www.googleadservices.com/pagead/aclk?sa=L&ai=DChcSEwi_i4aVsLztAhWNk7MKHasaB-UYABAAGgJxbg&ae=2"
           "&ohost=www.google.com&cid"
           "=CAESQOD2GBmu8c8e9_bkFzu8fIfTaLsbm0RCaSHqjc09RL59w6LHw0nHd0SyZLnWg6sDQvQIBbV2oOlfK8Qap1IaNuI&sig"
           "=AOD64_2HytX12-M9x0Qu7mfIGwpneZdbjQ&q&adurl&ved=2ahUKEwijl_2UsLztAhUoWN8KHZL8CNUQ0Qx6BAgGEAE")

driver.implicitly_wait(4)

driver.find_element_by_css_selector(
    "ul[class='navigation-menu__main navigation-menu__main--desktop'] li:nth-child(4)").click()
driver.find_element_by_css_selector("input[type='text']").send_keys("Canada")

deals = Select(driver.find_element_by_css_selector("div[css='1']"))
deals.select_by_index(1)

time = Select(driver.find_element_by_css_selector("div[css='2']"))
time.select_by_index(1)

driver.find_element_by_css_selector("div[class='j_Nx'] span").click()

driver.find_element_by_css_selector("div[class='c20M2-button']").click()

prices = driver.find_elements_by_css_selector("div[class='_kru _irc']")

for price in prices:
    print(price.text)

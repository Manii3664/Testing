from selenium import webdriver

driver = webdriver.Chrome(executable_path="c:\\chromedriver.exe")
driver.get("https://www.googleadservices.com/pagead/aclk?sa=L&ai=DChcSEwi_i4aVsLztAhWNk7MKHasaB-UYABAAGgJxbg&ae=2"
           "&ohost=www.google.com&cid"
           "=CAESQOD2GBmu8c8e9_bkFzu8fIfTaLsbm0RCaSHqjc09RL59w6LHw0nHd0SyZLnWg6sDQvQIBbV2oOlfK8Qap1IaNuI&sig"
           "=AOD64_2HytX12-M9x0Qu7mfIGwpneZdbjQ&q&adurl&ved=2ahUKEwijl_2UsLztAhUoWN8KHZL8CNUQ0Qx6BAgGEAE")

driver.implicitly_wait(4)

driver.find_element_by_css_selector("a[aria-label='Search for cars']").click()

childWindow= driver.window_handles[0]
driver.switch_to.window(childWindow)

value = driver.find_element_by_css_selector("div[class='cars-results-CarLocationSmartyInput'] input")
value.click()
value.clear()
value.send_keys("Montreal")

submit = driver.find_element_by_css_selector("#XYqx-submit").click()

prices = driver.find_elements_by_css_selector("div[class='_mou _ip2']")

for price in prices:
    print(price.text)
    if price.text == "C $48":
        price.click()

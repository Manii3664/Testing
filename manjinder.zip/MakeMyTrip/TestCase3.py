from selenium import webdriver

driver = webdriver.Chrome(executable_path="c:\\chromedriver.exe")
driver.get("https://www.googleadservices.com/pagead/aclk?sa=L&ai=DChcSEwi_i4aVsLztAhWNk7MKHasaB-UYABAAGgJxbg&ae=2"
           "&ohost=www.google.com&cid"
           "=CAESQOD2GBmu8c8e9_bkFzu8fIfTaLsbm0RCaSHqjc09RL59w6LHw0nHd0SyZLnWg6sDQvQIBbV2oOlfK8Qap1IaNuI&sig"
           "=AOD64_2HytX12-M9x0Qu7mfIGwpneZdbjQ&q&adurl&ved=2ahUKEwijl_2UsLztAhUoWN8KHZL8CNUQ0Qx6BAgGEAE")
driver.implicitly_wait(5)

driver.find_element_by_css_selector("div[class='link hotels'] a").click()
childWindow= driver.window_handles[0]
driver.switch_to.window(childWindow)

city=driver.find_element_by_id("oUsm-location-display-inner")
city.click()
city.clear()
city.send_keys("montreal")

driver.find_element_by_xpath("//button[@id='F56a-submit']").click()

childWindow= driver.window_handles[0]
driver.switch_to.window(childWindow)

prices=driver.find_elements_by_xpath("//div[@id='32877-booking-price']")

for price in prices:
     if price.text == "$129":
         price.click()
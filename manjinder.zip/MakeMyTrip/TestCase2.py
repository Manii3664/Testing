from selenium import webdriver

driver = webdriver.Chrome(executable_path="c:\\chromedriver.exe")
driver.get("https://www.googleadservices.com/pagead/aclk?sa=L&ai=DChcSEwi_i4aVsLztAhWNk7MKHasaB-UYABAAGgJxbg&ae=2"
           "&ohost=www.google.com&cid"
           "=CAESQOD2GBmu8c8e9_bkFzu8fIfTaLsbm0RCaSHqjc09RL59w6LHw0nHd0SyZLnWg6sDQvQIBbV2oOlfK8Qap1IaNuI&sig"
           "=AOD64_2HytX12-M9x0Qu7mfIGwpneZdbjQ&q&adurl&ved=2ahUKEwijl_2UsLztAhUoWN8KHZL8CNUQ0Qx6BAgGEAE")


driver.implicitly_wait(4)

arr = driver.find_element_by_css_selector("div[class='col col-1-2-m col-airport col-destination'] input[type='text']")
arr.click()
arr.send_keys("del")

cities = driver.find_elements_by_xpath("//div[@class='item-info']/div[1]")

for city in cities:
    if city.text == "New Delhi, India":
        city.click()

driver.find_element_by_css_selector("label[title='Round-trip']").click()

driver.find_element_by_css_selector("div[class='fieldBlock buttonBlock']")


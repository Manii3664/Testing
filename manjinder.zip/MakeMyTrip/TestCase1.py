from selenium import webdriver

driver = webdriver.Chrome(executable_path="c:\\chromedriver.exe")
driver.get("https://www.googleadservices.com/pagead/aclk?sa=L&ai=DChcSEwi_i4aVsLztAhWNk7MKHasaB-UYABAAGgJxbg&ae=2"
           "&ohost=www.google.com&cid"
           "=CAESQOD2GBmu8c8e9_bkFzu8fIfTaLsbm0RCaSHqjc09RL59w6LHw0nHd0SyZLnWg6sDQvQIBbV2oOlfK8Qap1IaNuI&sig"
           "=AOD64_2HytX12-M9x0Qu7mfIGwpneZdbjQ&q&adurl&ved=2ahUKEwijl_2UsLztAhUoWN8KHZL8CNUQ0Qx6BAgGEAE")


def login():
    driver.implicitly_wait(4)

    driver.find_element_by_css_selector("div[class='menu-label__wrapper']").click()
    childWindow = driver.window_handles[0]
    driver.switch_to.window(childWindow)

    driver.find_element_by_class_name("o3Q9-button-content").click()
    driver.switch_to.window(driver.window_handles[0])

    driver.find_element_by_css_selector("input[placeholder='Email address']").send_keys("harpreetmakkar89@gmail.com")
    driver.find_element_by_class_name("o3Q9-button-content").click()

    driver.switch_to.window(driver.window_handles[0])
    driver.find_element_by_css_selector(".o3Q9-button-content").click()
    driver.find_element_by_css_selector("div[role='button'] span").click()
